import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import os
import numpy as np

# 设置工作目录为脚本所在目录
script_path = os.path.abspath(__file__)
script_dir = os.path.dirname(script_path)
os.chdir(script_dir)

# 设置全局字体样式
font_style = {
    'family': 'Times New Roman',
    'weight': 'normal',
    'size': 20,
}

# ===================== 数据加载与预处理 =====================
# 加载Cantat-Gaudin2020数据
cat_ref_1 = pd.read_csv(
    '../../cross_match_modual(CG22)/catalog_public_ocs/Cantat_Gaudin2020.dat',
    skiprows=4, 
    delimiter='|',
    dtype=str  # 先全部读为字符串避免类型问题
)

# 列名处理
cat_ref_1.columns = cat_ref_1.columns.str.strip()

# 处理GLON和GLAT列（使用正则表达式分割更健壮）
tem_1 = cat_ref_1['GLON    GLAT'].str.strip()
split_result = tem_1.str.split(pat=r"\s+", n=1, expand=True)
cat_ref_1['GLON'] = pd.to_numeric(split_result[0], errors='coerce')
cat_ref_1['GLAT'] = pd.to_numeric(split_result[1], errors='coerce')

# 过滤无效年龄数据
cat_ref_1 = cat_ref_1[~cat_ref_1['ageNN'].str.contains('---', na=True)]
cat_ref_1['ageNN'] = pd.to_numeric(cat_ref_1['ageNN'], errors='coerce')

# 加载我们的数据
cat_ours = pd.read_csv('Table1_v4.csv', delimiter=',')
cat_ours = cat_ours.sort_values(by=['Age'])

# ===================== 可视化设置 =====================
# 创建输出目录
dist_dir = "img/"
os.makedirs(dist_dir, exist_ok=True)

# 创建画布
plt.figure(figsize=(10, 7))

# ===================== 绘制分布图 =====================
# 使用kdeplot替代distplot（更新后的推荐方式）
sns.kdeplot(
    data=cat_ours['Age'],
    color='blue',
    label='This work',
    linewidth=2,
    bw_method=0.2  # 带宽调整
)

sns.kdeplot(
    data=cat_ref_1['ageNN'],
    color='grey',
    label='CG20',
    linewidth=2,
    bw_method=0.2
)

# ===================== 图表美化 =====================
plt.ylabel('Cluster counts (density)', fontdict=font_style)
plt.xlabel('$log(age/yr)$', fontdict=font_style)

# 设置图例
plt.legend(
    prop={'family': 'Times New Roman', 'size': 16},
    frameon=False,
    loc='upper right'
)

# 调整坐标轴
plt.grid(True, linestyle='--', alpha=0.6)
plt.tight_layout()

# ===================== 保存与显示 =====================
output_path = os.path.join(dist_dir, "log_age_OCsvv_2.pdf")
plt.savefig(
    output_path,
    format='pdf',
    dpi=300,  # 更高分辨率
    bbox_inches='tight'
)

plt.show()

# ===================== 数据验证 =====================
print("\n数据验证:")
print(f"CG20数据集 - 有效年龄数量: {cat_ref_1['ageNN'].notna().sum()}")
print(f"我们的数据 - 有效年龄数量: {cat_ours['logAge_mean'].notna().sum()}")
print(f"GLON缺失值: {cat_ref_1['GLON'].isna().sum()}")
print(f"GLAT缺失值: {cat_ref_1['GLAT'].isna().sum()}")