import matplotlib.pylab as pylab
from pylab import *
from numpy import *
from scipy import *
import numpy as np
import matplotlib.gridspec as gs
from matplotlib.ticker import MaxNLocator

### Import BASE plotting functions
import plotresY
import plotres_multi
import os
file_path=os.path.abspath(__file__)
file_dir=os.path.dirname(file_path)
os.chdir(file_dir)
dist_dir='traces/'
if not os.path.exists(dist_dir):
    os.makedirs(dist_dir)

### Plotting singlePopMcmc results
print ('singlePopMcmc results:')
for root, dirs,files in os.walk('739_Res3'):
    for file in files:
        if file.endswith('.res'):
            file_path=os.path.join(root,file)
            res_single=loadtxt(file_path,skiprows=1)             ## load file
            plotresY.plotresY(res_single,startn=1000,color1='forestgreen',lw1=2)     ## plot results with function, customizing some default parameters
            savefig(dist_dir+file.split(".")[0]+'_Singlepop.pdf')     