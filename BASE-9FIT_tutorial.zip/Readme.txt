Explanation of BASE-9 Fitting Configuration Files for 739 Open Clusters (OCs):
Parallel Processing Implementation:
Python multiprocessing pools were employed for parallel computation.
Priors for each cluster were retrieved from Table1 , dynamically inserted into the base9.yaml configuration file, and then submitted to parallel processing tasks.
Sources of Parameter Values in the Configuration File:
Prior Values: All priors were sourced from Table1 in our paper.
